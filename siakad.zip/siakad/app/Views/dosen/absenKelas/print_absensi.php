<?php

header("Content-type: application/vnc-ms-excel");
header("Content-Disposition: attachment; filename=absensi.xls");

?>
<!DOCTYPE html>
<html lang="en">

<body>
  <div class="container">
    <h3 class="text-center">Absensi Mahasiswa</h3>
    <div class="row">
      <div class="col-md-4">
        <div class="table-responsive">
           <table class="table table-striped">
              <tr>
                 <th>Program Studi</th>
                 <th>:</th>
                 <th><?= $jadwal['prodi']; ?></th>
              </tr>
              <tr>
                 <th>Fakultas</th>
                 <th>:</th>
                 <th><?= $jadwal['fakultas']; ?></th>
              </tr>
              <tr>
                 <th>Kode</th>
                 <th>:</th>
                 <th><?= $jadwal['kode_matkul']; ?></th>
              </tr>
              <tr>
                 <th>Matkul</th>
                 <th>:</th>
                 <th><?= $jadwal['matkul']; ?></th>
              </tr>
              <tr>
                 <th>Jadwal</th>
                 <th>:</th>
                 <th><?= $jadwal['hari']. ' / ' .$jadwal['waktu']; ?></th>
              </tr>
              <tr>
                 <th>Dosen PA</th>
                 <th>:</th>
                 <th><?= $jadwal['nama_dosen']; ?></th>
              </tr>
           </table>
        </div>
      </div>
      
      
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="table-responsive">
           <table class="table table-bordered">
              <tr class="table-primary">
                 <th rowspan="2">No</th>
                 <th rowspan="2">NIM</th>
                 <th rowspan="2">Mahasiswa</th>
                 <th colspan="18">Pertemuan</th>
                 <th rowspan="2">%</th>
              </tr>
              <tr class="table-primary">
                 <?php for($i = 1; $i <= 18; $i++) : ?>
                  <td><?= $i; ?></td>
                 <?php endfor; ?>
              </tr>
              <?php $no = 1; foreach($mhs as $mm) : ?>
                 <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $mm['nim']; ?></td>
                    <td><?= $mm['nama_mhs']; ?></td>
                    <td>
                       <?php if($mm['p1'] == null) : ?>
                        <?= $mm['p1']; ?>
                        <?php elseif($mm['p1'] == 1) : ?>
                           <?= $mm['p1']; ?>
                         <?php elseif($mm['p1'] == 2) : ?>
                           <?= $mm['p1']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p2'] == null) : ?>
                        <?= $mm['p2']; ?>
                        <?php elseif($mm['p2'] == 1) : ?>
                           <?= $mm['p2']; ?>
                         <?php elseif($mm['p2'] == 2) : ?>
                           <?= $mm['p2']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p3'] == null) : ?>
                       <?= $mm['p3']; ?>
                        <?php elseif($mm['p3'] == 1) : ?>
                        <?= $mm['p3']; ?>
                         <?php elseif($mm['p3'] == 2) : ?>
                           <?= $mm['p3']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p4'] == null) : ?>
                       <?= $mm['p4']; ?>
                        <?php elseif($mm['p4'] == 1) : ?>
                        <?= $mm['p4']; ?>
                         <?php elseif($mm['p4'] == 2) : ?>
                           <?= $mm['p4']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p5'] == null) : ?>
                       <?= $mm['p5']; ?>
                        <?php elseif($mm['p5'] == 1) : ?>
                        <?= $mm['p5']; ?>
                         <?php elseif($mm['p5'] == 2) : ?>
                           <?= $mm['p5']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p6'] == null) : ?>
                       <?= $mm['p6']; ?>
                        <?php elseif($mm['p6'] == 1) : ?>
                        <?= $mm['p6']; ?>
                         <?php elseif($mm['p6'] == 2) : ?>
                           <?= $mm['p6']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p7'] == null) : ?>
                       <?= $mm['p7']; ?>
                        <?php elseif($mm['p7'] == 1) : ?>
                        <?= $mm['p7']; ?>
                         <?php elseif($mm['p7'] == 2) : ?>
                           <?= $mm['p7']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p8'] == null) : ?>
                       <?= $mm['p8']; ?>
                        <?php elseif($mm['p8'] == 1) : ?>
                        <?= $mm['p8']; ?>
                         <?php elseif($mm['p8'] == 2) : ?>
                           <?= $mm['p8']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p9'] == null) : ?>
                       <?= $mm['p9']; ?>
                        <?php elseif($mm['p9'] == 1) : ?>
                        <?= $mm['p9']; ?>
                         <?php elseif($mm['p9'] == 2) : ?>
                           <?= $mm['p9']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p10'] == null) : ?>
                       <?= $mm['p10']; ?>
                        <?php elseif($mm['p10'] == 1) : ?>
                        <?= $mm['p10']; ?>
                         <?php elseif($mm['p10'] == 2) : ?>
                           <?= $mm['p10']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p11'] == null) : ?>
                       <?= $mm['p11']; ?>
                        <?php elseif($mm['p11'] == 1) : ?>
                        <?= $mm['p11']; ?>
                         <?php elseif($mm['p11'] == 2) : ?>
                           <?= $mm['p11']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p12'] == null) : ?>
                       <?= $mm['p12']; ?>
                        <?php elseif($mm['p12'] == 1) : ?>
                        <?= $mm['p12']; ?>
                         <?php elseif($mm['p12'] == 2) : ?>
                           <?= $mm['p12']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p13'] == null) : ?>
                       <?= $mm['p13']; ?>
                        <?php elseif($mm['p13'] == 1) : ?>
                        <?= $mm['p13']; ?>
                         <?php elseif($mm['p13'] == 2) : ?>
                           <?= $mm['p13']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p14'] == null) : ?>
                       <?= $mm['p14']; ?>
                        <?php elseif($mm['p14'] == 1) : ?>
                        <?= $mm['p14']; ?>
                         <?php elseif($mm['p14'] == 2) : ?>
                           <?= $mm['p14']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p15'] == null) : ?>
                       <?= $mm['p15']; ?>
                        <?php elseif($mm['p15'] == 1) : ?>
                        <?= $mm['p15']; ?>
                         <?php elseif($mm['p15'] == 2) : ?>
                           <?= $mm['p15']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p16'] == null) : ?>
                       <?= $mm['p16']; ?>
                        <?php elseif($mm['p16'] == 1) : ?>
                        <?= $mm['p16']; ?>
                         <?php elseif($mm['p16'] == 2) : ?>
                           <?= $mm['p16']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p17'] == null) : ?>
                       <?= $mm['p17']; ?>
                        <?php elseif($mm['p17'] == 1) : ?>
                        <?= $mm['p17']; ?>
                         <?php elseif($mm['p17'] == 2) : ?>
                           <?= $mm['p17']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php if($mm['p18'] == null) : ?>
                       <?= $mm['p18']; ?>
                        <?php elseif($mm['p18'] == 1) : ?>
                        <?= $mm['p18']; ?>
                         <?php elseif($mm['p18'] == 2) : ?>
                           <?= $mm['p18']; ?>
                       <?php endif; ?>
                    </td>
                    <td>
                       <?php 
                       $absensi = ($mm['p1'] + $mm['p2'] + $mm['p3'] + $mm['p4'] + $mm['p5'] + $mm['p6'] + $mm['p7'] + $mm['p8'] + $mm['p9'] + $mm['p10'] + $mm['p11'] + $mm['p12'] + $mm['p13'] + $mm['p14'] + $mm['p15'] + $mm['p16'] + $mm['p17'] + $mm['p18']) / 36 * 100;
                       ?>
                       <?= number_format($absensi, 0); ?> %
                    </td>
                 </tr>
              <?php endforeach; ?>
           </table>
        </div>
      </div>
    </div>
    <table width="100%">
      <tr>
        <td></td>
        <td width="200">
          <p>Padang, Sumatera Barat <?= date('d-m-Y'); ?></p>
          <br>
          Pembimbing, 
          <br><br><br>
          <p><?= $jadwal['nama_dosen']; ?></p>
        </td>
      </tr>
    </table>
  </div>

<script>
  window.print();
</script>
</body>
</html>